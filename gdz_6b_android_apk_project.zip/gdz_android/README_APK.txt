ГДЗ 6Б — Android APK project

Это готовый Android-проект: приложение открывает встроенный сайт ГДЗ 6Б и автоматически запускает интерфейс AI.

ВАЖНО: в этой среде Android SDK/build-tools недоступны, поэтому сам бинарный APK здесь не был скомпилирован.

Чтобы получить APK без Android Studio:
1. Создай новый публичный репозиторий на GitHub.
2. Загрузи содержимое этой папки.
3. Открой Actions -> Build Android APK -> Run workflow.
4. После сборки скачай artifact GDZ-6B-APK и внутри будет app-debug.apk.

Сборка использует GitHub Actions и Gradle, а не требует API-ключа.
