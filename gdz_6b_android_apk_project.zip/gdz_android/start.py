from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import os, webbrowser
os.chdir(os.path.dirname(os.path.abspath(__file__)))
server=ThreadingHTTPServer(("127.0.0.1",8000),SimpleHTTPRequestHandler)
print("ГДЗ 6Б запущен: http://127.0.0.1:8000")
try:
    webbrowser.open("http://127.0.0.1:8000")
except: pass
server.serve_forever()
